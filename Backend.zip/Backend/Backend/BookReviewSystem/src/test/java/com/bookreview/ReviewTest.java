package com.bookreview;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.bookreview.entity.Review;
import com.bookreview.repo.ReviewRepository;

@TestMethodOrder(org.junit.jupiter.api.MethodOrderer.OrderAnnotation.class)
@SpringBootTest
public class ReviewTest {
	
	@Autowired
	ReviewRepository rrepo;
	
	@Test
	@Order(1)
	public void addReview() {
		Review rev = new Review();
		rev.setId(1);
		rev.setBookname("Beloved");
		rev.setName("User One");
		rev.setRating(5);
		rev.setReview("Excellent");
		
		rrepo.save(rev);
		assertNotNull(rrepo.findAll());
	}

}
