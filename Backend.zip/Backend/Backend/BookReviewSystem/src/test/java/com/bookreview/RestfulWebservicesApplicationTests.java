package com.bookreview;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulWebservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
