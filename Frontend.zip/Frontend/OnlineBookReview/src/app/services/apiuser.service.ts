import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../User';


@Injectable({
  providedIn: 'root'
})
export class ApiuserService {

  constructor(private http: HttpClient) { }

  addUser(data: any){
    return this.http.post(`http://localhost:9110/api/user/newregister`, data);
  }

  userLogin(data1:any){
     return this.http.post(`http://localhost:9110/api/user/login`, data1);
  }

  getUserByID(val:any){
    return this.http.get(`http://localhost:9110/api/user/get/${val}`);
  }

  supUser(val: any, id:number){
    return this.http.post(`http://localhost:9110/api/user/userupdate/${id}`, val);
  }

}
